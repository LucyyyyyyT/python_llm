# python_llm
![doctest](https://github.com/LucyyyyyyT/python_llm/actions/workflows/doctests.yml/badge.svg)

![integration-tests](https://github.com/LucyyyyyyT/python_llm/actions/workflows/test_integration.yml/badge.svg)

[![coverage](https://img.shields.io/badge/coverage-90%25-brightgreen)](#)

This is my python llm project.  

Check out my project on [PyPi] https://pypi.org/project/python-llm-lucy/

